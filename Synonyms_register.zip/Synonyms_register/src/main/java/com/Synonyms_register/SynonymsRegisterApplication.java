package com.Synonyms_register;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SynonymsRegisterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SynonymsRegisterApplication.class, args);
	}

}
